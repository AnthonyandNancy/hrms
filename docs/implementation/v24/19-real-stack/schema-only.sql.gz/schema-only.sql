-- MySQL dump 10.13  Distrib 8.4.13, for Linux (x86_64)
--
-- Host: localhost    Database: factoryhr_t19
-- ------------------------------------------------------
-- Server version	8.4.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assignments`
--

DROP TABLE IF EXISTS `assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assignments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `org_unit_id` bigint unsigned NOT NULL,
  `position_id` bigint unsigned DEFAULT NULL,
  `manager_assignment_id` bigint unsigned DEFAULT NULL,
  `assignment_type` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT '0',
  `valid_from` date NOT NULL,
  `valid_to` date NOT NULL DEFAULT '9999-12-31',
  `recorded_at` datetime(6) NOT NULL,
  `superseded_at` datetime(6) DEFAULT NULL,
  `source_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MANUAL',
  `source_id` bigint unsigned DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `assignments_manager_asof_idx` (`manager_assignment_id`,`valid_from`,`valid_to`),
  KEY `assignments_employment_id_index` (`employment_id`),
  KEY `assignments_org_unit_id_index` (`org_unit_id`),
  KEY `assignments_position_id_index` (`position_id`),
  KEY `assignments_manager_assignment_id_index` (`manager_assignment_id`),
  KEY `assignments_superseded_at_index` (`superseded_at`),
  CONSTRAINT `assignments_valid_range_check` CHECK ((`valid_from` < `valid_to`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `attendance_corrections`
--

DROP TABLE IF EXISTS `attendance_corrections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance_corrections` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `business_date` date NOT NULL,
  `requested_by` bigint unsigned NOT NULL,
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `corrected_punches_json` json NOT NULL,
  `case_id` bigint unsigned NOT NULL,
  `applied_at` timestamp(6) NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `attendance_corrections_case_id_unique` (`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `attendance_days`
--

DROP TABLE IF EXISTS `attendance_days`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance_days` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `business_date` date NOT NULL,
  `shift_template_id` bigint unsigned DEFAULT NULL,
  `scheduled_minutes` int unsigned NOT NULL DEFAULT '0',
  `worked_minutes` int unsigned NOT NULL DEFAULT '0',
  `overtime_minutes` int unsigned NOT NULL DEFAULT '0',
  `late_minutes` int unsigned NOT NULL DEFAULT '0',
  `early_leave_minutes` int unsigned NOT NULL DEFAULT '0',
  `absence_minutes` int unsigned NOT NULL DEFAULT '0',
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rule_version` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `calculated_at` timestamp(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `attendance_days_employment_id_business_date_unique` (`employment_id`,`business_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `attendance_devices`
--

DROP TABLE IF EXISTS `attendance_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance_devices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adapter` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `health` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'UNKNOWN',
  `last_seen_at` timestamp(6) NULL DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp(6) NULL DEFAULT NULL,
  `updated_at` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `attendance_devices_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `attendance_period_closures`
--

DROP TABLE IF EXISTS `attendance_period_closures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance_period_closures` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `month` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CLOSED',
  `closed_by` bigint unsigned DEFAULT NULL,
  `reopened_by` bigint unsigned DEFAULT NULL,
  `closed_at` timestamp NULL DEFAULT NULL,
  `reopened_at` timestamp NULL DEFAULT NULL,
  `reopen_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `current_fact_version_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `attendance_period_closures_month_unique` (`month`),
  KEY `attendance_period_closures_current_fact_version_id_index` (`current_fact_version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `attendance_rule_versions`
--

DROP TABLE IF EXISTS `attendance_rule_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance_rule_versions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_json` json NOT NULL,
  `effective_from` date NOT NULL,
  `checksum` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `attendance_rule_versions_version_unique` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `audit_events`
--

DROP TABLE IF EXISTS `audit_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `actor_user_id` bigint unsigned DEFAULT NULL,
  `actor_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USER',
  `action` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `before_json` json DEFAULT NULL,
  `after_json` json DEFAULT NULL,
  `metadata_json` json DEFAULT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `request_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occurred_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_events_aggregate_type_aggregate_id_index` (`aggregate_type`,`aggregate_id`),
  KEY `audit_events_actor_user_id_index` (`actor_user_id`),
  KEY `audit_events_request_id_index` (`request_id`),
  KEY `audit_events_occurred_at_index` (`occurred_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auth_events`
--

DROP TABLE IF EXISTS `auth_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `event_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `result` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `request_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadata_json` json DEFAULT NULL,
  `occurred_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `auth_events_user_id_index` (`user_id`),
  KEY `auth_events_event_type_index` (`event_type`),
  KEY `auth_events_request_id_index` (`request_id`),
  KEY `auth_events_occurred_at_index` (`occurred_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `authority_bindings`
--

DROP TABLE IF EXISTS `authority_bindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authority_bindings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `principal_id` bigint unsigned NOT NULL,
  `capability_code` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `anchor_type` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `anchor_id` bigint unsigned DEFAULT NULL,
  `anchor_key` bigint unsigned NOT NULL DEFAULT '0',
  `field_profile` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purpose_code` varchar(48) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valid_from` timestamp NOT NULL,
  `valid_to` timestamp NOT NULL,
  `source_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` bigint unsigned DEFAULT NULL,
  `auth_version` bigint unsigned NOT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `authority_binding_version_unique` (`principal_id`,`capability_code`,`anchor_type`,`anchor_key`,`valid_from`,`auth_version`),
  KEY `authority_bindings_principal_id_index` (`principal_id`),
  KEY `authority_bindings_valid_from_index` (`valid_from`),
  KEY `authority_bindings_valid_to_index` (`valid_to`),
  KEY `authority_bindings_last_used_at_index` (`last_used_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `benefit_enrollments`
--

DROP TABLE IF EXISTS `benefit_enrollments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `benefit_enrollments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `plan_id` bigint unsigned NOT NULL,
  `base_amount_cents` bigint unsigned NOT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `created_by` bigint unsigned NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `benefit_enrollments_employment_id_plan_id_effective_from_unique` (`employment_id`,`plan_id`,`effective_from`),
  KEY `benefit_enrollments_employment_id_index` (`employment_id`),
  KEY `benefit_enrollments_plan_id_index` (`plan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `benefit_plans`
--

DROP TABLE IF EXISTS `benefit_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `benefit_plans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employer_rate` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_rate` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `created_by` bigint unsigned NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `benefit_plans_code_version_unique` (`code`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `benefit_transactions`
--

DROP TABLE IF EXISTS `benefit_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `benefit_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `enrollment_id` bigint unsigned NOT NULL,
  `period` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_amount_cents` bigint unsigned NOT NULL,
  `employee_amount_cents` bigint unsigned NOT NULL,
  `employer_amount_cents` bigint unsigned NOT NULL,
  `total_amount_cents` bigint unsigned NOT NULL,
  `payroll_run_id` bigint unsigned DEFAULT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'RECORDED',
  `created_by` bigint unsigned NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `entry_type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'RECORD',
  `reversal_of_id` bigint unsigned DEFAULT NULL,
  `reversed_by_id` bigint unsigned DEFAULT NULL,
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `benefit_transactions_entry_unique` (`enrollment_id`,`period`,`entry_type`),
  UNIQUE KEY `benefit_transactions_reversal_unique` (`reversal_of_id`),
  KEY `benefit_transactions_employment_id_index` (`employment_id`),
  KEY `benefit_transactions_enrollment_id_index` (`enrollment_id`),
  KEY `benefit_transactions_payroll_run_id_index` (`payroll_run_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `break_glass_grants`
--

DROP TABLE IF EXISTS `break_glass_grants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `break_glass_grants` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `requester_user_id` bigint unsigned NOT NULL,
  `approver_user_id` bigint unsigned NOT NULL,
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `granted_at` timestamp NOT NULL,
  `expires_at` timestamp NOT NULL,
  `revoked_at` timestamp NULL DEFAULT NULL,
  `scope_json` json NOT NULL,
  `alert_sent_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `break_glass_grants_requester_user_id_index` (`requester_user_id`),
  KEY `break_glass_grants_approver_user_id_index` (`approver_user_id`),
  KEY `break_glass_grants_granted_at_index` (`granted_at`),
  KEY `break_glass_grants_expires_at_index` (`expires_at`),
  KEY `break_glass_grants_revoked_at_index` (`revoked_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `business_trip_records`
--

DROP TABLE IF EXISTS `business_trip_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `business_trip_records` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `destination` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purpose` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `case_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `cancel_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `business_trip_records_case_id_index` (`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `candidate_applications`
--

DROP TABLE IF EXISTS `candidate_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidate_applications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `candidate_id` bigint unsigned NOT NULL,
  `requisition_id` bigint unsigned NOT NULL,
  `opening_id` bigint unsigned DEFAULT NULL,
  `stage` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NEW',
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `source` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `candidate_application_unique` (`candidate_id`,`requisition_id`),
  KEY `candidate_application_stage_idx` (`requisition_id`,`stage`),
  KEY `candidate_applications_candidate_id_index` (`candidate_id`),
  KEY `candidate_applications_requisition_id_index` (`requisition_id`),
  KEY `candidate_applications_opening_id_index` (`opening_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `candidate_communications`
--

DROP TABLE IF EXISTS `candidate_communications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidate_communications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `candidate_id` bigint unsigned NOT NULL,
  `channel` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direction` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `consent_basis` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `candidate_communications_candidate_id_index` (`candidate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `candidate_conversions`
--

DROP TABLE IF EXISTS `candidate_conversions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidate_conversions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `candidate_id` bigint unsigned NOT NULL,
  `employment_id` bigint unsigned NOT NULL,
  `person_id` bigint unsigned NOT NULL,
  `offer_id` bigint unsigned NOT NULL,
  `org_unit_id` bigint unsigned NOT NULL,
  `employee_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'COMPLETED',
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `onboarding_case_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `candidate_conversions_candidate_id_unique` (`candidate_id`),
  KEY `candidate_conversions_employment_id_index` (`employment_id`),
  KEY `candidate_conversions_person_id_index` (`person_id`),
  KEY `candidate_conversions_offer_id_index` (`offer_id`),
  KEY `candidate_conversions_org_unit_id_index` (`org_unit_id`),
  KEY `candidate_conversions_onboarding_case_id_index` (`onboarding_case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `candidate_evaluations`
--

DROP TABLE IF EXISTS `candidate_evaluations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidate_evaluations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `candidate_id` bigint unsigned NOT NULL,
  `interview_id` bigint unsigned DEFAULT NULL,
  `evaluator_user_id` bigint unsigned NOT NULL,
  `rating` tinyint unsigned NOT NULL,
  `recommendation` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `strengths` text COLLATE utf8mb4_unicode_ci,
  `concerns` text COLLATE utf8mb4_unicode_ci,
  `comments` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'RECORDED',
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `candidate_evaluations_candidate_id_index` (`candidate_id`),
  KEY `candidate_evaluations_interview_id_index` (`interview_id`),
  KEY `candidate_evaluations_evaluator_user_id_index` (`evaluator_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `candidate_imports`
--

DROP TABLE IF EXISTS `candidate_imports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidate_imports` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `requisition_id` bigint unsigned DEFAULT NULL,
  `source` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MANUAL',
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'COMPLETED',
  `row_count` int unsigned NOT NULL,
  `accepted_count` int unsigned NOT NULL,
  `rejected_count` int unsigned NOT NULL,
  `rows_json` json NOT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `candidate_imports_requisition_id_index` (`requisition_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `candidates`
--

DROP TABLE IF EXISTS `candidates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `display_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(254) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_ciphertext` text COLLATE utf8mb4_unicode_ci,
  `email_hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NEW',
  `linked_person_id` bigint unsigned DEFAULT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `candidates_email_hash_unique` (`email_hash`),
  UNIQUE KEY `candidates_mobile_hash_unique` (`mobile_hash`),
  KEY `candidates_linked_person_id_index` (`linked_person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `capabilities`
--

DROP TABLE IF EXISTS `capabilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `capabilities` (
  `code` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resource` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actions_json` json NOT NULL,
  `anchor_types_json` json NOT NULL,
  `field_profile_max` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `risk` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sod_group` varchar(48) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `synced_at` timestamp NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `case_events`
--

DROP TABLE IF EXISTS `case_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `case_id` bigint unsigned NOT NULL,
  `event_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actor_user_id` bigint unsigned DEFAULT NULL,
  `payload_json` json NOT NULL,
  `occurred_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `case_events_case_id_occurred_at_index` (`case_id`,`occurred_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `case_members`
--

DROP TABLE IF EXISTS `case_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_members` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `case_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `role` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `case_members_case_id_user_id_role_unique` (`case_id`,`user_id`,`role`),
  KEY `case_members_user_id_role_index` (`user_id`,`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cases`
--

DROP TABLE IF EXISTS `cases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cases` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `case_no` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_id` bigint unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload_json` json NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `effect_status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NONE',
  `requester_user_id` bigint unsigned NOT NULL,
  `template_id` bigint unsigned DEFAULT NULL,
  `template_version` int unsigned NOT NULL,
  `template_snapshot_json` json DEFAULT NULL,
  `business_date` date NOT NULL,
  `submitted_at` timestamp NULL DEFAULT NULL,
  `closed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cases_case_no_unique` (`case_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `company_profile`
--

DROP TABLE IF EXISTS `company_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company_profile` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_code` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CN',
  `timezone` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Asia/Shanghai',
  `currency_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CNY',
  `calendar_policy_json` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_templates`
--

DROP TABLE IF EXISTS `contract_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `published_at` datetime(6) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `contract_templates_code_version_unique` (`code`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dashboard_snapshots`
--

DROP TABLE IF EXISTS `dashboard_snapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_snapshots` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `metric_code` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `as_of` date NOT NULL,
  `value` bigint NOT NULL DEFAULT '0',
  `unit` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'COUNT',
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'AVAILABLE',
  `reason` text COLLATE utf8mb4_unicode_ci,
  `source_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload_json` json DEFAULT NULL,
  `computed_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dashboard_snapshots_metric_code_as_of_scope_hash_unique` (`metric_code`,`as_of`,`scope_hash`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `decisions`
--

DROP TABLE IF EXISTS `decisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `decisions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `case_id` bigint unsigned NOT NULL,
  `node_key` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actor_user_id` bigint unsigned NOT NULL,
  `decision_seq` int unsigned NOT NULL,
  `action` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `actor_snapshot_json` json NOT NULL,
  `template_version` int unsigned NOT NULL,
  `evidence_hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `decided_at` timestamp NOT NULL,
  `request_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `decision_actor_seq_unique` (`case_id`,`node_key`,`actor_user_id`,`decision_seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `demo_datasets`
--

DROP TABLE IF EXISTS `demo_datasets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `demo_datasets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `dataset` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mode` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `populated_json` json NOT NULL,
  `deferred_json` json NOT NULL,
  `fixture_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seeded_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `demo_datasets_dataset_unique` (`dataset`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `owner_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` bigint unsigned NOT NULL,
  `category` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_object_id` bigint unsigned NOT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `signed_at` datetime(6) DEFAULT NULL,
  `sha256` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` date DEFAULT NULL,
  `retention_class` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `legal_hold` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `documents_owner_category_version_unique` (`owner_type`,`owner_id`,`category`,`version`),
  KEY `documents_file_object_id_index` (`file_object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `effects`
--

DROP TABLE IF EXISTS `effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `effects` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `case_id` bigint unsigned NOT NULL,
  `decision_id` bigint unsigned DEFAULT NULL,
  `effect_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `effect_seq` int unsigned NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheduled_for` date DEFAULT NULL,
  `applied_at` timestamp NULL DEFAULT NULL,
  `failed_at` timestamp NULL DEFAULT NULL,
  `failure_reason` text COLLATE utf8mb4_unicode_ci,
  `attempts` int unsigned NOT NULL DEFAULT '0',
  `reversal_of_id` bigint unsigned DEFAULT NULL,
  `payload_json` json DEFAULT NULL,
  `requires_escalation` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `effect_aggregate_seq_unique` (`effect_type`,`aggregate_id`,`effect_seq`),
  UNIQUE KEY `effects_reversal_of_unique` (`reversal_of_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employee_certificates`
--

DROP TABLE IF EXISTS `employee_certificates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_certificates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `certificate_type` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `certificate_no` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `issuer` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `issued_on` date DEFAULT NULL,
  `expires_on` date DEFAULT NULL,
  `document_id` bigint unsigned DEFAULT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `superseded_at` datetime(6) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_certificates_employment_id_index` (`employment_id`),
  KEY `employee_certificates_superseded_at_index` (`superseded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employee_change_requests`
--

DROP TABLE IF EXISTS `employee_change_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_change_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `requested_by` bigint unsigned NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `diff_json` json NOT NULL,
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `case_id` bigint unsigned DEFAULT NULL,
  `submitted_at` datetime(6) DEFAULT NULL,
  `decided_at` datetime(6) DEFAULT NULL,
  `decided_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_change_requests_employment_id_index` (`employment_id`),
  KEY `employee_change_requests_requested_by_index` (`requested_by`),
  KEY `employee_change_requests_case_id_index` (`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employee_compensations`
--

DROP TABLE IF EXISTS `employee_compensations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_compensations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `contract_version_id` bigint unsigned DEFAULT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `approved_case_id` bigint unsigned DEFAULT NULL,
  `source_type` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_id` bigint unsigned DEFAULT NULL,
  `content_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supersedes_id` bigint unsigned DEFAULT NULL,
  `currency` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CNY',
  `base_salary_cents` bigint unsigned NOT NULL,
  `salary_scheme_code` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payroll_scheme_id` bigint unsigned DEFAULT NULL,
  `payroll_scheme_version` int unsigned DEFAULT NULL,
  `parameter_overrides_json` json DEFAULT NULL,
  `created_by` bigint unsigned NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employee_compensations_employment_effective_unique` (`employment_id`,`effective_from`),
  KEY `employee_compensations_employment_id_index` (`employment_id`),
  KEY `employee_compensations_contract_version_idx` (`contract_version_id`),
  KEY `employee_compensations_scheme_idx` (`payroll_scheme_id`,`payroll_scheme_version`),
  KEY `employee_compensations_hash_idx` (`content_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employee_contacts`
--

DROP TABLE IF EXISTS `employee_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_contacts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `relationship` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_ciphertext` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_emergency` tinyint(1) NOT NULL DEFAULT '0',
  `is_primary` tinyint(1) NOT NULL DEFAULT '0',
  `recorded_at` datetime(6) NOT NULL,
  `superseded_at` datetime(6) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_contacts_employment_id_index` (`employment_id`),
  KEY `employee_contacts_superseded_at_index` (`superseded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employee_educations`
--

DROP TABLE IF EXISTS `employee_educations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_educations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `school` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `degree` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `major` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `recorded_at` datetime(6) NOT NULL,
  `superseded_at` datetime(6) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_educations_employment_id_index` (`employment_id`),
  KEY `employee_educations_superseded_at_index` (`superseded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employee_experiences`
--

DROP TABLE IF EXISTS `employee_experiences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_experiences` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `company` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `leave_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `recorded_at` datetime(6) NOT NULL,
  `superseded_at` datetime(6) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_experiences_employment_id_index` (`employment_id`),
  KEY `employee_experiences_superseded_at_index` (`superseded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employee_import_batches`
--

DROP TABLE IF EXISTS `employee_import_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_import_batches` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uploaded_by` bigint unsigned NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'VALIDATING',
  `original_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_rows` int unsigned NOT NULL DEFAULT '0',
  `valid_rows` int unsigned NOT NULL DEFAULT '0',
  `failed_rows` int unsigned NOT NULL DEFAULT '0',
  `errors_json` json DEFAULT NULL,
  `validated_at` datetime(6) DEFAULT NULL,
  `committed_at` datetime(6) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_import_batches_uploaded_by_index` (`uploaded_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employment_contract_versions`
--

DROP TABLE IF EXISTS `employment_contract_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employment_contract_versions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `terms_version` int unsigned NOT NULL,
  `document_version` int unsigned NOT NULL,
  `file_object_id` bigint unsigned DEFAULT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date NOT NULL DEFAULT '9999-12-31',
  `agreed_salary_minor` bigint DEFAULT NULL,
  `agreed_currency` char(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `terms_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'RECORDED',
  `activated_at` datetime(6) DEFAULT NULL,
  `activated_by` bigint unsigned DEFAULT NULL,
  `expires_at` date DEFAULT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `source_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CASE',
  `source_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `contract_id` bigint unsigned DEFAULT NULL,
  `change_type` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `snapshot_json` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `contract_terms_version_unique` (`employment_id`,`terms_version`),
  KEY `employment_contract_versions_employment_id_index` (`employment_id`),
  KEY `contract_terms_hash_idx` (`terms_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employment_contracts`
--

DROP TABLE IF EXISTS `employment_contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employment_contracts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `contract_no` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contract_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `signed_on` date DEFAULT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `version` int unsigned NOT NULL DEFAULT '1',
  `previous_contract_id` bigint unsigned DEFAULT NULL,
  `renewed_by_id` bigint unsigned DEFAULT NULL,
  `template_id` bigint unsigned DEFAULT NULL,
  `terms_summary` text COLLATE utf8mb4_unicode_ci,
  `work_location` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `probation_end_date` date DEFAULT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `source_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'API',
  `source_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `terminated_on` date DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` bigint unsigned DEFAULT NULL,
  `delete_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employment_contracts_contract_no_unique` (`contract_no`),
  KEY `employment_contracts_employment_id_index` (`employment_id`),
  KEY `employment_contracts_previous_contract_id_index` (`previous_contract_id`),
  KEY `employment_contracts_renewed_by_id_index` (`renewed_by_id`),
  KEY `employment_contracts_deleted_idx` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employment_terms`
--

DROP TABLE IF EXISTS `employment_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employment_terms` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `version` int unsigned NOT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date NOT NULL DEFAULT '9999-12-31',
  `probation_end_date` date DEFAULT NULL,
  `work_location` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `work_schedule` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `salary_scheme_code` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_salary_minor` bigint unsigned DEFAULT NULL,
  `salary_currency` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CNY',
  `notice_period_days` smallint unsigned NOT NULL DEFAULT '0',
  `confidentiality` tinyint(1) NOT NULL DEFAULT '0',
  `non_compete` tinyint(1) NOT NULL DEFAULT '0',
  `signed_at` datetime(6) DEFAULT NULL,
  `source_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MANUAL',
  `source_id` bigint unsigned DEFAULT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employment_terms_version_unique` (`employment_id`,`version`),
  KEY `employment_terms_employment_id_index` (`employment_id`),
  CONSTRAINT `employment_terms_valid_range_check` CHECK ((`effective_from` < `effective_to`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employment_user_links`
--

DROP TABLE IF EXISTS `employment_user_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employment_user_links` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `employment_id` bigint unsigned NOT NULL,
  `valid_from` date NOT NULL,
  `valid_to` date NOT NULL DEFAULT '9999-12-31',
  `recorded_at` datetime(6) NOT NULL,
  `source_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MANUAL',
  `source_id` bigint unsigned DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employment_user_links_user_id_employment_id_valid_from_unique` (`user_id`,`employment_id`,`valid_from`),
  KEY `employment_user_links_employment_id_index` (`employment_id`),
  CONSTRAINT `employment_user_links_valid_range_check` CHECK ((`valid_from` < `valid_to`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employments`
--

DROP TABLE IF EXISTS `employments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `person_id` bigint unsigned NOT NULL,
  `employee_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employment_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PROBATION',
  `valid_from` date NOT NULL,
  `valid_to` date NOT NULL DEFAULT '9999-12-31',
  `hire_date` date NOT NULL,
  `termination_date` date DEFAULT NULL,
  `seniority_start_date` date NOT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `superseded_at` datetime(6) DEFAULT NULL,
  `source_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MANUAL',
  `source_id` bigint unsigned DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `archived_at` timestamp NULL DEFAULT NULL,
  `archived_by` bigint unsigned DEFAULT NULL,
  `archive_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employments_employee_no_unique` (`employee_no`),
  KEY `employments_person_id_index` (`person_id`),
  KEY `employments_superseded_at_index` (`superseded_at`),
  KEY `employments_archived_at_index` (`archived_at`),
  CONSTRAINT `employments_valid_range_check` CHECK ((`valid_from` < `valid_to`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `export_jobs`
--

DROP TABLE IF EXISTS `export_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `export_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `report_code` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purpose` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fields_json` json NOT NULL,
  `field_whitelist_json` json DEFAULT NULL,
  `filters_json` json NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'QUEUED',
  `row_count` bigint unsigned NOT NULL DEFAULT '0',
  `source_hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_object_id` bigint unsigned DEFAULT NULL,
  `expires_at` timestamp NOT NULL,
  `download_count` int unsigned NOT NULL DEFAULT '0',
  `max_downloads` int unsigned NOT NULL DEFAULT '5',
  `requested_by` bigint unsigned NOT NULL,
  `download_token_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `download_token_expires_at` timestamp NOT NULL,
  `watermark` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `audit_trail_json` json DEFAULT NULL,
  `part_no` int unsigned NOT NULL DEFAULT '1',
  `total_parts` int unsigned NOT NULL DEFAULT '1',
  `parent_job_id` bigint unsigned DEFAULT NULL,
  `failure_reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feature_flags`
--

DROP TABLE IF EXISTS `feature_flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feature_flags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `flag` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `updated_by` bigint unsigned DEFAULT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `feature_flags_flag_unique` (`flag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `file_objects`
--

DROP TABLE IF EXISTS `file_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_objects` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `storage_key` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sha256` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mime` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size_bytes` bigint unsigned NOT NULL,
  `owner_user_id` bigint unsigned DEFAULT NULL,
  `purpose` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `retention_class` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `legal_hold` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `file_objects_storage_key_unique` (`storage_key`),
  KEY `file_objects_sha256_index` (`sha256`),
  KEY `file_objects_owner_user_id_index` (`owner_user_id`),
  KEY `file_objects_purpose_index` (`purpose`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `holidays`
--

DROP TABLE IF EXISTS `holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `holidays` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `holidays_date_unique` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `iam_data_scope_policies`
--

DROP TABLE IF EXISTS `iam_data_scope_policies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `iam_data_scope_policies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `template_code` varchar(48) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `anchor_type` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `iam_data_scope_policies_template_code_unique` (`template_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `iam_field_policies`
--

DROP TABLE IF EXISTS `iam_field_policies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `iam_field_policies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `field_key` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_profile` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `iam_field_policies_field_key_unique` (`field_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `idempotency_keys`
--

DROP TABLE IF EXISTS `idempotency_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `idempotency_keys` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `principal_id` bigint unsigned NOT NULL,
  `scope` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `response_status` smallint unsigned DEFAULT NULL,
  `response_body_json` json DEFAULT NULL,
  `resource_type` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resource_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idempotency_keys_principal_id_scope_key_unique` (`principal_id`,`scope`,`key`),
  KEY `idempotency_keys_status_expires_at_index` (`status`,`expires_at`),
  KEY `idempotency_keys_expires_at_index` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `interviews`
--

DROP TABLE IF EXISTS `interviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interviews` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `candidate_id` bigint unsigned NOT NULL,
  `requisition_id` bigint unsigned NOT NULL,
  `scheduled_at` datetime(6) NOT NULL,
  `duration_minutes` smallint unsigned NOT NULL DEFAULT '60',
  `interviewer` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mode` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'VIDEO',
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SCHEDULED',
  `recommendation` varchar(24) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feedback` text COLLATE utf8mb4_unicode_ci,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `interviews_candidate_id_index` (`candidate_id`),
  KEY `interviews_requisition_id_index` (`requisition_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `leave_accounts`
--

DROP TABLE IF EXISTS `leave_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_accounts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `leave_type_id` bigint unsigned NOT NULL,
  `opened_on` date NOT NULL,
  `closed_on` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `leave_accounts_employment_id_leave_type_id_opened_on_unique` (`employment_id`,`leave_type_id`,`opened_on`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `leave_balances`
--

DROP TABLE IF EXISTS `leave_balances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_balances` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `leave_type_id` bigint unsigned NOT NULL,
  `as_of` date NOT NULL,
  `granted` int NOT NULL DEFAULT '0',
  `reserved` int NOT NULL DEFAULT '0',
  `consumed` int NOT NULL DEFAULT '0',
  `released` int NOT NULL DEFAULT '0',
  `expired` int NOT NULL DEFAULT '0',
  `adjusted` int NOT NULL DEFAULT '0',
  `reversed` int NOT NULL DEFAULT '0',
  `balance` int NOT NULL DEFAULT '0',
  `updated_at` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `leave_balances_employment_id_leave_type_id_unique` (`employment_id`,`leave_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `leave_ledger_entries`
--

DROP TABLE IF EXISTS `leave_ledger_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_ledger_entries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `leave_type_id` bigint unsigned NOT NULL,
  `account` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity_minutes` int NOT NULL,
  `business_date` date NOT NULL,
  `effective_on` date NOT NULL,
  `source_type` varchar(48) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `case_id` bigint unsigned DEFAULT NULL,
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entry_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recorded_at` timestamp(6) NOT NULL,
  `created_at` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_2f3de277683b3a68f27ac8d66a88a306` (`employment_id`,`leave_type_id`,`source_type`,`source_id`,`account`),
  KEY `leave_ledger_entries_case_id_index` (`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `leave_policy_versions`
--

DROP TABLE IF EXISTS `leave_policy_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_policy_versions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `leave_type_id` bigint unsigned NOT NULL,
  `version` int unsigned NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PUBLISHED',
  `effective_from` date NOT NULL,
  `effective_to` date NOT NULL,
  `applies_to_json` json NOT NULL,
  `accrual_json` json NOT NULL,
  `payroll_treatment` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_ratio_scaled` int unsigned DEFAULT NULL,
  `carryover_json` json DEFAULT NULL,
  `min_notice_days` smallint unsigned NOT NULL DEFAULT '0',
  `max_consecutive_days` smallint unsigned DEFAULT NULL,
  `requires_attachment_over_days` smallint unsigned DEFAULT NULL,
  `allow_half_day` tinyint(1) NOT NULL DEFAULT '1',
  `legal_basis` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published_at` datetime(6) NOT NULL,
  `published_by` bigint unsigned NOT NULL,
  `retired_at` datetime(6) DEFAULT NULL,
  `retire_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `leave_policy_type_version_unique` (`leave_type_id`,`version`),
  KEY `leave_policy_effective_idx` (`leave_type_id`,`effective_from`),
  KEY `leave_policy_state_idx` (`leave_type_id`,`status`,`effective_to`),
  KEY `leave_policy_versions_leave_type_id_index` (`leave_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `leave_request_projections`
--

DROP TABLE IF EXISTS `leave_request_projections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_request_projections` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `actor_user_id` bigint unsigned DEFAULT NULL,
  `org_unit_id` bigint unsigned DEFAULT NULL,
  `leave_type_id` bigint unsigned NOT NULL,
  `leave_policy_version_id` bigint unsigned DEFAULT NULL,
  `case_id` bigint unsigned NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `minutes` int NOT NULL,
  `state` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `leave_request_projections_case_id_unique` (`case_id`),
  KEY `leave_request_projections_actor_user_id_index` (`actor_user_id`),
  KEY `leave_request_projections_leave_policy_version_id_index` (`leave_policy_version_id`),
  KEY `leave_request_projections_org_unit_id_index` (`org_unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `leave_types`
--

DROP TABLE IF EXISTS `leave_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_statutory` tinyint(1) NOT NULL DEFAULT '0',
  `is_annual` tinyint(1) NOT NULL DEFAULT '0',
  `unit` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `annual_entitlement_days` decimal(6,2) DEFAULT NULL,
  `requires_attachment` tinyint(1) NOT NULL DEFAULT '0',
  `allow_negative` tinyint(1) NOT NULL DEFAULT '0',
  `expiry_rule_json` json DEFAULT NULL,
  `legal_basis` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `leave_types_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `legal_entity_calendars`
--

DROP TABLE IF EXISTS `legal_entity_calendars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `legal_entity_calendars` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `timezone` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `workweek_json` json NOT NULL,
  `standard_day_minutes` smallint unsigned NOT NULL DEFAULT '480',
  `version` int unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `legal_holds`
--

DROP TABLE IF EXISTS `legal_holds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `legal_holds` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `retention_class` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `case_reference` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `starts_at` timestamp NOT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `released_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lifecycle_intents`
--

DROP TABLE IF EXISTS `lifecycle_intents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lifecycle_intents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `case_id` bigint unsigned NOT NULL,
  `case_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `subject_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_id` bigint unsigned DEFAULT NULL,
  `intent_json` json NOT NULL,
  `employment_id` bigint unsigned DEFAULT NULL,
  `result_employment_id` bigint unsigned DEFAULT NULL,
  `effective_at` datetime(6) DEFAULT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `offer_id` bigint unsigned DEFAULT NULL,
  `planned_effective_on` date DEFAULT NULL,
  `deduplication_key` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `before_json` json DEFAULT NULL,
  `after_json` json DEFAULT NULL,
  `effect_result_json` json DEFAULT NULL,
  `detail_frozen_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lifecycle_intents_case_id_unique` (`case_id`),
  UNIQUE KEY `lifecycle_intent_offer_unique` (`case_type`,`offer_id`),
  KEY `lifecycle_intents_employment_id_index` (`employment_id`),
  KEY `lifecycle_intents_result_employment_id_index` (`result_employment_id`),
  KEY `lifecycle_intents_offer_id_index` (`offer_id`),
  KEY `lifecycle_intents_planned_effective_on_index` (`planned_effective_on`),
  KEY `lifecycle_intents_deduplication_key_index` (`deduplication_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lifecycle_tasks`
--

DROP TABLE IF EXISTS `lifecycle_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lifecycle_tasks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `case_id` bigint unsigned NOT NULL,
  `employment_id` bigint unsigned DEFAULT NULL,
  `task_code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `required` tinyint(1) NOT NULL DEFAULT '1',
  `assignee_role` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `waiver_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `completed_at` datetime(6) DEFAULT NULL,
  `completed_by_user_id` bigint unsigned DEFAULT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `source_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CASE',
  `source_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lifecycle_task_case_code_unique` (`case_id`,`task_code`),
  KEY `lifecycle_tasks_case_id_index` (`case_id`),
  KEY `lifecycle_tasks_employment_id_index` (`employment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_attempts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `succeeded` tinyint(1) NOT NULL DEFAULT '0',
  `attempted_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `login_attempt_lookup_idx` (`username`,`ip`,`attempted_at`),
  KEY `login_attempts_username_index` (`username`),
  KEY `login_attempts_ip_index` (`ip`),
  KEY `login_attempts_attempted_at_index` (`attempted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `menu_overrides`
--

DROP TABLE IF EXISTS `menu_overrides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_overrides` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `page_code` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menu_overrides_page_code_unique` (`page_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mfa_factors`
--

DROP TABLE IF EXISTS `mfa_factors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mfa_factors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret_ciphertext` text COLLATE utf8mb4_unicode_ci,
  `credential_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `public_key` text COLLATE utf8mb4_unicode_ci,
  `label` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `disabled_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mfa_factor_credential_unique` (`user_id`,`credential_id`),
  KEY `mfa_factors_user_id_index` (`user_id`),
  KEY `mfa_factors_credential_id_index` (`credential_id`),
  KEY `mfa_factors_disabled_at_index` (`disabled_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migration_issues`
--

DROP TABLE IF EXISTS `migration_issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migration_issues` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `run_id` bigint unsigned NOT NULL,
  `stg_id` bigint unsigned DEFAULT NULL,
  `severity` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_row_number` int unsigned DEFAULT NULL,
  `field` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `migration_issues_run_severity_idx` (`run_id`,`severity`),
  KEY `migration_issues_code_idx` (`code`,`created_at`),
  KEY `migration_issues_stg_id_index` (`stg_id`),
  CONSTRAINT `migration_issues_run_id_foreign` FOREIGN KEY (`run_id`) REFERENCES `migration_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migration_runs`
--

DROP TABLE IF EXISTS `migration_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migration_runs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `domain` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_file` text COLLATE utf8mb4_unicode_ci,
  `source_file_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `mapping_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mode` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rows_read` int unsigned NOT NULL DEFAULT '0',
  `rows_valid` int unsigned NOT NULL DEFAULT '0',
  `rows_created` int unsigned NOT NULL DEFAULT '0',
  `rows_updated` int unsigned NOT NULL DEFAULT '0',
  `rows_skipped` int unsigned NOT NULL DEFAULT '0',
  `rows_failed` int unsigned NOT NULL DEFAULT '0',
  `started_at` timestamp NULL DEFAULT NULL,
  `finished_at` timestamp NULL DEFAULT NULL,
  `report_json` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `migration_runs_domain_file_idx` (`domain`,`source_file_hash`),
  KEY `migration_runs_status_index` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migration_shadow_rows`
--

DROP TABLE IF EXISTS `migration_shadow_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migration_shadow_rows` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `domain` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `natural_key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `migration_run_id` bigint unsigned NOT NULL,
  `source_id` bigint unsigned DEFAULT NULL,
  `data_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload_json` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `migration_shadow_rows_domain_natural_key_unique` (`domain`,`natural_key`),
  KEY `migration_shadow_rows_migration_run_id_index` (`migration_run_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notice_acknowledgements`
--

DROP TABLE IF EXISTS `notice_acknowledgements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice_acknowledgements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `notice_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `acknowledged_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notice_ack_unique` (`notice_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notice_audience_snapshots`
--

DROP TABLE IF EXISTS `notice_audience_snapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice_audience_snapshots` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `notice_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `recorded_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notice_audience_snapshot_unique` (`notice_id`,`user_id`),
  KEY `notice_audience_snapshots_notice_id_index` (`notice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notice_reminders`
--

DROP TABLE IF EXISTS `notice_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice_reminders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `notice_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `requested_by` bigint unsigned NOT NULL,
  `notification_id` bigint unsigned DEFAULT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notice_reminder_unique` (`notice_id`,`user_id`,`requested_by`),
  KEY `notice_reminder_notice_recorded_idx` (`notice_id`,`recorded_at`),
  KEY `notice_reminders_notice_id_index` (`notice_id`),
  KEY `notice_reminders_user_id_index` (`user_id`),
  KEY `notice_reminders_requested_by_index` (`requested_by`),
  KEY `notice_reminders_notification_id_index` (`notification_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notice_templates`
--

DROP TABLE IF EXISTS `notice_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `body_template` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `variables_json` json NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PUBLISHED',
  `created_by` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notice_templates_code_version_unique` (`code`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notices`
--

DROP TABLE IF EXISTS `notices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `audience_json` json NOT NULL,
  `publish_at` timestamp NOT NULL,
  `retract_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint unsigned NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `requires_ack` tinyint(1) NOT NULL DEFAULT '0',
  `audience_count` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `approval_case_id` bigint unsigned DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `approved_by` bigint unsigned DEFAULT NULL,
  `archived_at` timestamp NULL DEFAULT NULL,
  `archived_by` bigint unsigned DEFAULT NULL,
  `archive_previous_status` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `archive_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template_id` bigint unsigned DEFAULT NULL,
  `template_version` bigint unsigned DEFAULT NULL,
  `template_code` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notices_publish_at_index` (`publish_at`),
  KEY `notices_status_index` (`status`),
  KEY `notices_approval_case_id_index` (`approval_case_id`),
  KEY `notices_template_id_index` (`template_id`),
  KEY `notices_expires_at_index` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notification_deliveries`
--

DROP TABLE IF EXISTS `notification_deliveries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_deliveries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `notification_outbox_id` bigint unsigned NOT NULL,
  `notification_id` bigint unsigned DEFAULT NULL,
  `template_code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipient_user_id` bigint unsigned NOT NULL,
  `channel` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `attempts` int unsigned NOT NULL DEFAULT '0',
  `provider_message_id` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_error` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notification_deliveries_notification_outbox_id_unique` (`notification_outbox_id`),
  UNIQUE KEY `notification_delivery_notification_user_unique` (`notification_id`,`recipient_user_id`),
  KEY `notification_deliveries_status_index` (`status`),
  KEY `notification_delivery_notification_user_idx` (`notification_id`,`recipient_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notification_outbox`
--

DROP TABLE IF EXISTS `notification_outbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_outbox` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `event_key` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `template_code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipient_user_id` bigint unsigned NOT NULL,
  `payload_json` json NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notification_outbox_event_key_unique` (`event_key`),
  KEY `notification_outbox_status_index` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notification_templates`
--

DROP TABLE IF EXISTS `notification_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `channel` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'IN_APP',
  `subject` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notification_templates_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `event_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload_json` json NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notification_event_user_unique` (`event_key`,`user_id`),
  KEY `notifications_user_id_index` (`user_id`),
  KEY `notifications_read_at_index` (`read_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `offers`
--

DROP TABLE IF EXISTS `offers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `offers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `candidate_id` bigint unsigned NOT NULL,
  `requisition_id` bigint unsigned NOT NULL,
  `version` int unsigned NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `base_salary_minor` bigint unsigned NOT NULL,
  `salary_currency` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `salary_scheme_code` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date NOT NULL,
  `case_id` bigint unsigned DEFAULT NULL,
  `onboarding_case_id` bigint unsigned DEFAULT NULL,
  `accepted_at` timestamp NULL DEFAULT NULL,
  `declined_at` timestamp NULL DEFAULT NULL,
  `superseded_by_id` bigint unsigned DEFAULT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `offers_candidate_id_version_unique` (`candidate_id`,`version`),
  KEY `offers_candidate_id_index` (`candidate_id`),
  KEY `offers_requisition_id_index` (`requisition_id`),
  KEY `offers_case_id_index` (`case_id`),
  KEY `offers_onboarding_case_id_index` (`onboarding_case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `onboarding_checklist_templates`
--

DROP TABLE IF EXISTS `onboarding_checklist_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `onboarding_checklist_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `task_code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '1',
  `assignee_role` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` smallint unsigned NOT NULL DEFAULT '0',
  `recorded_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `onboarding_checklist_templates_task_code_unique` (`task_code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `org_unit_closure`
--

DROP TABLE IF EXISTS `org_unit_closure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `org_unit_closure` (
  `ancestor_id` bigint unsigned NOT NULL,
  `descendant_id` bigint unsigned NOT NULL,
  `depth` smallint unsigned NOT NULL,
  `valid_from` date NOT NULL,
  `valid_to` date NOT NULL DEFAULT '9999-12-31',
  `recorded_at` datetime(6) NOT NULL,
  `superseded_at` datetime(6) DEFAULT NULL,
  `source_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MANUAL',
  `source_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`ancestor_id`,`descendant_id`,`valid_from`),
  CONSTRAINT `org_unit_closure_valid_range_check` CHECK ((`valid_from` < `valid_to`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `org_unit_headcount_versions`
--

DROP TABLE IF EXISTS `org_unit_headcount_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `org_unit_headcount_versions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `org_unit_id` bigint unsigned NOT NULL,
  `headcount_limit` int unsigned NOT NULL,
  `effective_from` date NOT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `recorded_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `org_unit_headcount_versions_unit_effective_unique` (`org_unit_id`,`effective_from`),
  KEY `org_unit_headcount_versions_org_unit_id_index` (`org_unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `org_units`
--

DROP TABLE IF EXISTS `org_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `org_units` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint unsigned DEFAULT NULL,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `manager_employment_id` bigint unsigned DEFAULT NULL,
  `headcount_limit` int unsigned DEFAULT NULL,
  `valid_from` date NOT NULL,
  `valid_to` date NOT NULL DEFAULT '9999-12-31',
  `recorded_at` datetime(6) NOT NULL,
  `superseded_at` datetime(6) DEFAULT NULL,
  `source_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MANUAL',
  `source_id` bigint unsigned DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `org_units_code_unique` (`code`),
  KEY `org_units_parent_id_index` (`parent_id`),
  KEY `org_units_superseded_at_index` (`superseded_at`),
  KEY `org_units_manager_employment_id_index` (`manager_employment_id`),
  CONSTRAINT `org_units_valid_range_check` CHECK ((`valid_from` < `valid_to`))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `outbox_events`
--

DROP TABLE IF EXISTS `outbox_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `outbox_events` (
  `id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_type` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_version` bigint unsigned NOT NULL,
  `payload_json` json NOT NULL,
  `occurred_at` timestamp NOT NULL,
  `available_at` timestamp NOT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `attempts` int unsigned NOT NULL DEFAULT '0',
  `last_error` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `outbox_aggregate_idx` (`aggregate_type`,`aggregate_id`,`aggregate_version`),
  KEY `outbox_events_event_type_index` (`event_type`),
  KEY `outbox_events_available_at_index` (`available_at`),
  KEY `outbox_events_published_at_index` (`published_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `overtime_policy_versions`
--

DROP TABLE IF EXISTS `overtime_policy_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `overtime_policy_versions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `version` int unsigned NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PUBLISHED',
  `effective_from` date NOT NULL,
  `effective_to` date NOT NULL,
  `time_unit_minutes` smallint unsigned NOT NULL DEFAULT '30',
  `multiplier` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1.500000',
  `statutory_holiday_multiplier` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '3.000000',
  `allow_pay` tinyint(1) NOT NULL DEFAULT '1',
  `allow_timeoff` tinyint(1) NOT NULL DEFAULT '1',
  `allocation` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'EMPLOYEE_CHOICE',
  `rounding` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'HALF_UP',
  `legal_basis` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published_at` datetime(6) NOT NULL,
  `published_by` bigint unsigned NOT NULL,
  `retired_at` datetime(6) DEFAULT NULL,
  `retired_by` bigint unsigned DEFAULT NULL,
  `retire_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `overtime_policy_version_unique` (`version`),
  KEY `overtime_policy_effective_idx` (`effective_from`,`effective_to`),
  KEY `overtime_policy_state_idx` (`status`,`retired_at`,`effective_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `overtime_records`
--

DROP TABLE IF EXISTS `overtime_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `overtime_records` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `business_date` date NOT NULL,
  `minutes` int NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `case_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `overtime_records_case_id_index` (`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `overtime_requests`
--

DROP TABLE IF EXISTS `overtime_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `overtime_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `business_date` date NOT NULL,
  `declared_minutes` int NOT NULL,
  `confirmed_minutes` int DEFAULT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'APPROVED',
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `case_id` bigint unsigned DEFAULT NULL,
  `overtime_record_id` bigint unsigned DEFAULT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `policy_version_id` bigint unsigned DEFAULT NULL,
  `policy_snapshot_json` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `overtime_requests_employment_id_business_date_unique` (`employment_id`,`business_date`),
  UNIQUE KEY `overtime_requests_overtime_record_id_unique` (`overtime_record_id`),
  KEY `overtime_requests_case_id_index` (`case_id`),
  KEY `overtime_requests_policy_version_id_index` (`policy_version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `overtime_settlements`
--

DROP TABLE IF EXISTS `overtime_settlements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `overtime_settlements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `overtime_record_id` bigint unsigned NOT NULL,
  `employment_id` bigint unsigned NOT NULL,
  `method` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `minutes` int NOT NULL,
  `payroll_run_id` bigint unsigned DEFAULT NULL,
  `leave_ledger_entry_id` bigint unsigned DEFAULT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `overtime_settlements_overtime_record_id_unique` (`overtime_record_id`),
  KEY `overtime_settlements_employment_id_index` (`employment_id`),
  KEY `overtime_settlements_payroll_run_id_index` (`payroll_run_id`),
  KEY `overtime_settlements_leave_ledger_entry_id_index` (`leave_ledger_entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payroll_adjustments`
--

DROP TABLE IF EXISTS `payroll_adjustments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_adjustments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `run_id` bigint unsigned DEFAULT NULL,
  `employment_id` bigint unsigned NOT NULL,
  `item_code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount_cents` int NOT NULL,
  `reason` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `case_id` bigint unsigned DEFAULT NULL,
  `approved_by` bigint unsigned NOT NULL,
  `effective_period` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `payroll_adjustments_run_id_index` (`run_id`),
  KEY `payroll_adjustments_employment_id_index` (`employment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payroll_input_snapshots`
--

DROP TABLE IF EXISTS `payroll_input_snapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_input_snapshots` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `run_id` bigint unsigned NOT NULL,
  `employment_id` bigint unsigned NOT NULL,
  `snapshot_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INPUT',
  `snapshot_version` int unsigned NOT NULL DEFAULT '1',
  `payload_json` json NOT NULL,
  `source_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payroll_snapshot_unique` (`run_id`,`employment_id`,`snapshot_type`,`snapshot_version`),
  KEY `payroll_input_snapshots_run_id_index` (`run_id`),
  KEY `payroll_input_snapshots_employment_id_index` (`employment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payroll_item_versions`
--

DROP TABLE IF EXISTS `payroll_item_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_item_versions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `payroll_item_id` bigint unsigned NOT NULL,
  `version` int unsigned NOT NULL,
  `name` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `taxable` tinyint(1) NOT NULL DEFAULT '1',
  `insurable` tinyint(1) NOT NULL DEFAULT '1',
  `calculation` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'FIXED',
  `formula_json` json DEFAULT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `effective_from` date NOT NULL,
  `effective_to` date NOT NULL DEFAULT '9999-12-31',
  `retired_at` datetime(6) DEFAULT NULL,
  `retire_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp(6) NULL DEFAULT NULL,
  `updated_at` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payroll_item_version_unique` (`payroll_item_id`,`version`),
  KEY `payroll_item_effective_idx` (`payroll_item_id`,`effective_from`),
  KEY `payroll_item_versions_payroll_item_id_index` (`payroll_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payroll_items`
--

DROP TABLE IF EXISTS `payroll_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `created_at` timestamp(6) NULL DEFAULT NULL,
  `updated_at` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payroll_items_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payroll_receipts`
--

DROP TABLE IF EXISTS `payroll_receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_receipts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `run_id` bigint unsigned NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `external_reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `received_at` datetime(6) NOT NULL,
  `reconciled_at` datetime(6) DEFAULT NULL,
  `metadata_json` json DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `payroll_receipts_run_id_index` (`run_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payroll_rule_versions`
--

DROP TABLE IF EXISTS `payroll_rule_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_rule_versions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `scheme_item_id` bigint unsigned NOT NULL,
  `version` int unsigned NOT NULL,
  `ast_json` json NOT NULL,
  `stage` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'EARNING',
  `dependencies_json` json DEFAULT NULL,
  `rounding_mode` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'HALF_UP',
  `unit` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CENT',
  `engine_version` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PAYROLL_RULE_V1',
  `hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `created_by` bigint unsigned NOT NULL,
  `published_by` bigint unsigned DEFAULT NULL,
  `published_at` datetime(6) DEFAULT NULL,
  `retire_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payroll_rule_version_unique` (`scheme_item_id`,`version`),
  KEY `payroll_rule_publish_lookup` (`scheme_item_id`,`status`,`version`),
  KEY `payroll_rule_versions_scheme_item_id_index` (`scheme_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payroll_run_employees`
--

DROP TABLE IF EXISTS `payroll_run_employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_run_employees` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `run_id` bigint unsigned NOT NULL,
  `employment_id` bigint unsigned NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `gross_cents` bigint NOT NULL DEFAULT '0',
  `taxable_cents` bigint NOT NULL DEFAULT '0',
  `deductions_cents` bigint NOT NULL DEFAULT '0',
  `net_cents` bigint NOT NULL DEFAULT '0',
  `employer_cost_cents` bigint NOT NULL DEFAULT '0',
  `employee_si_cents` bigint NOT NULL DEFAULT '0',
  `employee_hf_cents` bigint NOT NULL DEFAULT '0',
  `employer_si_cents` bigint NOT NULL DEFAULT '0',
  `employer_hf_cents` bigint NOT NULL DEFAULT '0',
  `tax_cents` bigint NOT NULL DEFAULT '0',
  `ytd_taxable_opening_cents` bigint NOT NULL DEFAULT '0',
  `ytd_tax_withheld_opening_cents` bigint NOT NULL DEFAULT '0',
  `ytd_applied` tinyint(1) NOT NULL DEFAULT '0',
  `ytd_applied_at` datetime(6) DEFAULT NULL,
  `failure_reason` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp(6) NULL DEFAULT NULL,
  `updated_at` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payroll_run_employee_unique` (`run_id`,`employment_id`),
  KEY `payroll_run_employees_run_id_index` (`run_id`),
  KEY `payroll_run_employees_employment_id_index` (`employment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payroll_run_members`
--

DROP TABLE IF EXISTS `payroll_run_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_run_members` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `run_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `member_role` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `assigned_by` bigint unsigned NOT NULL,
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valid_from` datetime(6) NOT NULL,
  `created_at` timestamp(6) NULL DEFAULT NULL,
  `updated_at` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payroll_run_member_unique` (`run_id`,`user_id`,`member_role`),
  KEY `payroll_run_member_user_run_idx` (`user_id`,`run_id`),
  KEY `payroll_run_members_run_id_index` (`run_id`),
  KEY `payroll_run_members_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payroll_runs`
--

DROP TABLE IF EXISTS `payroll_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_runs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `scheme_id` bigint unsigned NOT NULL,
  `period` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `earning_period_start` date NOT NULL,
  `earning_period_end` date NOT NULL,
  `posting_period` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pay_date` date NOT NULL,
  `cutoff_at` datetime(6) NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `run_type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'REGULAR',
  `correction_of_run_id` bigint unsigned DEFAULT NULL,
  `prepared_by` bigint unsigned NOT NULL,
  `reviewed_by` bigint unsigned DEFAULT NULL,
  `approved_by` bigint unsigned DEFAULT NULL,
  `published_by` bigint unsigned DEFAULT NULL,
  `paid_by` bigint unsigned DEFAULT NULL,
  `gross_cents` bigint NOT NULL DEFAULT '0',
  `deductions_cents` bigint NOT NULL DEFAULT '0',
  `net_cents` bigint NOT NULL DEFAULT '0',
  `employer_cost_cents` bigint NOT NULL DEFAULT '0',
  `input_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rule_version` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `snapshot_version` int unsigned NOT NULL DEFAULT '1',
  `reopen_count` int unsigned NOT NULL DEFAULT '0',
  `reopen_approvals_json` json DEFAULT NULL,
  `reopened_at` datetime(6) DEFAULT NULL,
  `approval_case_id` bigint unsigned DEFAULT NULL,
  `approval_effect_status` varchar(24) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancellation_reason` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_export_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_export_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `export_generated_at` datetime(6) DEFAULT NULL,
  `calculated_at` datetime(6) DEFAULT NULL,
  `reviewed_at` datetime(6) DEFAULT NULL,
  `approved_at` datetime(6) DEFAULT NULL,
  `published_at` datetime(6) DEFAULT NULL,
  `paid_at` datetime(6) DEFAULT NULL,
  `closed_at` datetime(6) DEFAULT NULL,
  `created_at` timestamp(6) NULL DEFAULT NULL,
  `updated_at` timestamp(6) NULL DEFAULT NULL,
  `payslip_status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'UNPUBLISHED',
  `disbursement_status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NOT_REGISTERED',
  `disbursement_reference` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disbursement_registered_by` bigint unsigned DEFAULT NULL,
  `disbursement_registered_at` datetime(6) DEFAULT NULL,
  `correction_baseline_run_id` bigint unsigned DEFAULT NULL,
  `correction_sequence` int unsigned NOT NULL DEFAULT '1',
  `prior_correction_ids_json` json DEFAULT NULL,
  `correction_target_net_cents` bigint DEFAULT NULL,
  `correction_baseline_net_cents` bigint DEFAULT NULL,
  `correction_delta_net_cents` bigint DEFAULT NULL,
  `correction_cumulative_net_cents` bigint DEFAULT NULL,
  `correction_status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'OPEN',
  `correction_voided_at` datetime(6) DEFAULT NULL,
  `correction_void_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payroll_runs_scheme_id_index` (`scheme_id`),
  KEY `payroll_runs_correction_of_run_id_index` (`correction_of_run_id`),
  KEY `payroll_runs_input_hash_index` (`input_hash`),
  KEY `payroll_runs_correction_baseline_run_id_index` (`correction_baseline_run_id`),
  KEY `payroll_correction_period_lookup` (`correction_of_run_id`,`period`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payroll_scheme_items`
--

DROP TABLE IF EXISTS `payroll_scheme_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_scheme_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `scheme_id` bigint unsigned NOT NULL,
  `payroll_item_id` bigint unsigned DEFAULT NULL,
  `item_code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `calculation` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'FIXED',
  `amount_cents` int NOT NULL DEFAULT '0',
  `rate_scaled` bigint DEFAULT NULL,
  `basis` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'BASE_SALARY',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `taxable` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp(6) NULL DEFAULT NULL,
  `updated_at` timestamp(6) NULL DEFAULT NULL,
  `formula_json` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payroll_scheme_item_code_unique` (`scheme_id`,`item_code`),
  KEY `payroll_scheme_items_scheme_id_index` (`scheme_id`),
  KEY `payroll_scheme_items_payroll_item_id_index` (`payroll_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payroll_schemes`
--

DROP TABLE IF EXISTS `payroll_schemes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_schemes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `frequency` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MONTHLY',
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `valid_from` date NOT NULL,
  `valid_to` date NOT NULL DEFAULT '9999-12-31',
  `proration_divisor` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ANNUAL_DAYS_365',
  `rounding_mode` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'HALF_UP',
  `overtime_multiplier` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1.500000',
  `allow_negative_net` tinyint(1) NOT NULL DEFAULT '0',
  `base_salary_cents` bigint NOT NULL DEFAULT '0',
  `created_at` timestamp(6) NULL DEFAULT NULL,
  `updated_at` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payroll_schemes_code_version_unique` (`code`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payroll_ytd`
--

DROP TABLE IF EXISTS `payroll_ytd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_ytd` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `tax_year` smallint unsigned NOT NULL,
  `taxable_income_cents` bigint NOT NULL DEFAULT '0',
  `tax_withheld_cents` bigint NOT NULL DEFAULT '0',
  `social_insurance_cents` bigint NOT NULL DEFAULT '0',
  `housing_fund_cents` bigint NOT NULL DEFAULT '0',
  `gross_cents` bigint NOT NULL DEFAULT '0',
  `net_cents` bigint NOT NULL DEFAULT '0',
  `carry_forward_cents` bigint NOT NULL DEFAULT '0',
  `last_run_id` bigint unsigned DEFAULT NULL,
  `source_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PAYROLL',
  `source_id` bigint unsigned DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payroll_ytd_employment_id_tax_year_unique` (`employment_id`,`tax_year`),
  KEY `payroll_ytd_employment_id_index` (`employment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payroll_ytd_ledger_entries`
--

DROP TABLE IF EXISTS `payroll_ytd_ledger_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_ytd_ledger_entries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `tax_year` smallint unsigned NOT NULL,
  `source_run_id` bigint unsigned NOT NULL,
  `source_employee_id` bigint unsigned NOT NULL,
  `source_type` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entry_type` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PUBLISH',
  `taxable_income_cents` bigint NOT NULL DEFAULT '0',
  `tax_withheld_cents` bigint NOT NULL DEFAULT '0',
  `social_insurance_cents` bigint NOT NULL DEFAULT '0',
  `housing_fund_cents` bigint NOT NULL DEFAULT '0',
  `gross_cents` bigint NOT NULL DEFAULT '0',
  `net_cents` bigint NOT NULL DEFAULT '0',
  `carry_forward_cents` bigint NOT NULL DEFAULT '0',
  `source_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payroll_ytd_ledger_source_unique` (`source_run_id`,`employment_id`,`entry_type`),
  KEY `payroll_ytd_ledger_entries_employment_id_index` (`employment_id`),
  KEY `payroll_ytd_ledger_entries_tax_year_index` (`tax_year`),
  KEY `payroll_ytd_ledger_entries_source_run_id_index` (`source_run_id`),
  KEY `payroll_ytd_ledger_entries_source_employee_id_index` (`source_employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payslip_lines`
--

DROP TABLE IF EXISTS `payslip_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payslip_lines` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `payslip_id` bigint unsigned NOT NULL,
  `item_code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity_scaled` bigint NOT NULL DEFAULT '0',
  `unit` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MONTH',
  `rate_scaled` bigint NOT NULL DEFAULT '0',
  `amount_cents` bigint NOT NULL,
  `taxable` tinyint(1) NOT NULL DEFAULT '1',
  `source_type` varchar(48) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `payslip_line_order_idx` (`payslip_id`,`sort_order`),
  KEY `payslip_lines_payslip_id_index` (`payslip_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payslips`
--

DROP TABLE IF EXISTS `payslips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payslips` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `run_id` bigint unsigned NOT NULL,
  `employment_id` bigint unsigned NOT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `gross_cents` bigint NOT NULL DEFAULT '0',
  `deductions_cents` bigint NOT NULL DEFAULT '0',
  `net_cents` bigint NOT NULL DEFAULT '0',
  `employer_cost_cents` bigint NOT NULL DEFAULT '0',
  `published_at` datetime(6) DEFAULT NULL,
  `pdf_file_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp(6) NULL DEFAULT NULL,
  `updated_at` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payslip_run_employee_unique` (`run_id`,`employment_id`),
  KEY `payslips_run_id_index` (`run_id`),
  KEY `payslips_employment_id_index` (`employment_id`),
  KEY `payslips_published_at_index` (`published_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `people_onboarding_drafts`
--

DROP TABLE IF EXISTS `people_onboarding_drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `people_onboarding_drafts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idempotency_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `case_id` bigint unsigned DEFAULT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `payload_ciphertext` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` bigint unsigned NOT NULL,
  `consumed_at` datetime(6) DEFAULT NULL,
  `created_at` timestamp(6) NULL DEFAULT NULL,
  `updated_at` timestamp(6) NULL DEFAULT NULL,
  `pending_employee_no` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `people_onboarding_drafts_idempotency_key_unique` (`idempotency_key`),
  UNIQUE KEY `people_onboarding_drafts_case_id_unique` (`case_id`),
  UNIQUE KEY `people_onboarding_drafts_pending_employee_no_unique` (`pending_employee_no`),
  KEY `people_onboarding_drafts_employee_no_index` (`employee_no`),
  KEY `people_onboarding_drafts_status_index` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `performance_appeals`
--

DROP TABLE IF EXISTS `performance_appeals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance_appeals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `review_id` bigint unsigned NOT NULL,
  `case_id` bigint unsigned NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'OPEN',
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `performance_appeals_case_id_unique` (`case_id`),
  UNIQUE KEY `performance_appeals_review_id_unique` (`review_id`),
  KEY `performance_appeals_review_id_index` (`review_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `performance_bonus_mappings`
--

DROP TABLE IF EXISTS `performance_bonus_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance_bonus_mappings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `performance_snapshot_id` bigint unsigned NOT NULL,
  `cycle_id` bigint unsigned NOT NULL,
  `employment_id` bigint unsigned NOT NULL,
  `payroll_item_code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount_cents` bigint NOT NULL,
  `mapping_version` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'V1',
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `approved_by` bigint unsigned DEFAULT NULL,
  `approved_at` datetime(6) DEFAULT NULL,
  `source_revision` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `performance_bonus_mapping_version_unique` (`performance_snapshot_id`,`period`,`mapping_version`),
  KEY `performance_bonus_payroll_input_idx` (`employment_id`,`period`,`status`),
  KEY `performance_bonus_mappings_performance_snapshot_id_index` (`performance_snapshot_id`),
  KEY `performance_bonus_mappings_cycle_id_index` (`cycle_id`),
  KEY `performance_bonus_mappings_employment_id_index` (`employment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `performance_calibrations`
--

DROP TABLE IF EXISTS `performance_calibrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance_calibrations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cycle_id` bigint unsigned NOT NULL,
  `review_id` bigint unsigned NOT NULL,
  `previous_rating` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `calibrated_rating` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `calibrated_by` bigint unsigned NOT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `performance_calibrations_cycle_id_index` (`cycle_id`),
  KEY `performance_calibrations_review_id_index` (`review_id`),
  KEY `performance_calibrations_calibrated_by_index` (`calibrated_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `performance_cycles`
--

DROP TABLE IF EXISTS `performance_cycles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance_cycles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period_from` date NOT NULL,
  `period_to` date NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `published_at` datetime(6) DEFAULT NULL,
  `published_by` bigint unsigned DEFAULT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `performance_cycles_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `performance_feedback`
--

DROP TABLE IF EXISTS `performance_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance_feedback` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cycle_id` bigint unsigned NOT NULL,
  `review_id` bigint unsigned DEFAULT NULL,
  `from_employment_id` bigint unsigned NOT NULL,
  `to_employment_id` bigint unsigned NOT NULL,
  `feedback_type` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `anonymous` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'RECORDED',
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `performance_feedback_cycle_id_index` (`cycle_id`),
  KEY `performance_feedback_review_id_index` (`review_id`),
  KEY `performance_feedback_from_employment_id_index` (`from_employment_id`),
  KEY `performance_feedback_to_employment_id_index` (`to_employment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `performance_goals`
--

DROP TABLE IF EXISTS `performance_goals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance_goals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cycle_id` bigint unsigned NOT NULL,
  `employment_id` bigint unsigned NOT NULL,
  `indicator_id` bigint unsigned DEFAULT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_value` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` smallint unsigned NOT NULL DEFAULT '0',
  `due_on` date DEFAULT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `performance_goals_cycle_id_index` (`cycle_id`),
  KEY `performance_goals_employment_id_index` (`employment_id`),
  KEY `performance_goals_indicator_id_index` (`indicator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `performance_indicators`
--

DROP TABLE IF EXISTS `performance_indicators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance_indicators` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_source` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `performance_indicators_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `performance_result_snapshots`
--

DROP TABLE IF EXISTS `performance_result_snapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance_result_snapshots` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cycle_id` bigint unsigned NOT NULL,
  `review_id` bigint unsigned NOT NULL,
  `employment_id` bigint unsigned NOT NULL,
  `self_rating` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manager_rating` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `calibrated_rating` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `final_rating` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `published_at` datetime(6) NOT NULL,
  `published_by` bigint unsigned NOT NULL,
  `created_at` timestamp(6) NULL DEFAULT NULL,
  `updated_at` timestamp(6) NULL DEFAULT NULL,
  `score_scaled` int DEFAULT NULL,
  `grade` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_revision` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `performance_result_snapshot_unique` (`cycle_id`,`review_id`),
  KEY `performance_result_snapshots_cycle_id_index` (`cycle_id`),
  KEY `performance_result_snapshots_review_id_index` (`review_id`),
  KEY `performance_result_snapshots_employment_id_index` (`employment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `performance_reviews`
--

DROP TABLE IF EXISTS `performance_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance_reviews` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cycle_id` bigint unsigned NOT NULL,
  `employment_id` bigint unsigned NOT NULL,
  `manager_employment_id` bigint unsigned DEFAULT NULL,
  `goals_text` text COLLATE utf8mb4_unicode_ci,
  `self_assessment` text COLLATE utf8mb4_unicode_ci,
  `manager_assessment` text COLLATE utf8mb4_unicode_ci,
  `self_rating` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manager_rating` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `calibrated_rating` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `submitted_at` timestamp NULL DEFAULT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `performance_reviews_cycle_id_employment_id_unique` (`cycle_id`,`employment_id`),
  KEY `performance_reviews_cycle_id_index` (`cycle_id`),
  KEY `performance_reviews_employment_id_index` (`employment_id`),
  KEY `performance_reviews_manager_employment_id_index` (`manager_employment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `performance_templates`
--

DROP TABLE IF EXISTS `performance_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sections_json` json NOT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `performance_templates_code_version_unique` (`code`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `persons`
--

DROP TABLE IF EXISTS `persons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `persons` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `legal_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `preferred_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_type` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_number_ciphertext` text COLLATE utf8mb4_unicode_ci,
  `id_number_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `gender` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationality` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_ciphertext` text COLLATE utf8mb4_unicode_ci,
  `email` varchar(254) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `persons_id_type_id_number_hash_unique` (`id_type`,`id_number_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `platform_installation_states`
--

DROP TABLE IF EXISTS `platform_installation_states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `platform_installation_states` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `instance_key` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `admin_username` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_user_id` bigint unsigned DEFAULT NULL,
  `application_version` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `catalog_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_error` text COLLATE utf8mb4_unicode_ci,
  `started_at` datetime(6) DEFAULT NULL,
  `completed_at` datetime(6) DEFAULT NULL,
  `created_at` timestamp(6) NULL DEFAULT NULL,
  `updated_at` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `platform_installation_states_instance_key_unique` (`instance_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `position_grades`
--

DROP TABLE IF EXISTS `position_grades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `position_grades` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` smallint unsigned NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `position_grades_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `position_qualifications`
--

DROP TABLE IF EXISTS `position_qualifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `position_qualifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `position_id` bigint unsigned NOT NULL,
  `version` int unsigned NOT NULL,
  `requirements_json` json NOT NULL,
  `effective_from` date NOT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `position_qualifications_position_id_version_unique` (`position_id`,`version`),
  KEY `position_qualifications_position_id_index` (`position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `positions`
--

DROP TABLE IF EXISTS `positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `positions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `org_unit_id` bigint unsigned DEFAULT NULL,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `grade` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `headcount_limit` int unsigned DEFAULT NULL,
  `valid_from` date NOT NULL,
  `valid_to` date NOT NULL DEFAULT '9999-12-31',
  `recorded_at` datetime(6) NOT NULL,
  `superseded_at` datetime(6) DEFAULT NULL,
  `source_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MANUAL',
  `source_id` bigint unsigned DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `positions_code_unique` (`code`),
  KEY `positions_org_unit_id_index` (`org_unit_id`),
  CONSTRAINT `positions_valid_range_check` CHECK ((`valid_from` < `valid_to`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `punch_records`
--

DROP TABLE IF EXISTS `punch_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `punch_records` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `device_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `punched_at_utc` datetime(6) NOT NULL,
  `source_local_offset` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `raw_payload_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `punch_records_employment_id_raw_payload_hash_unique` (`employment_id`,`raw_payload_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recovery_codes`
--

DROP TABLE IF EXISTS `recovery_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recovery_codes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `code_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `recovery_code_unique` (`user_id`,`code_hash`),
  KEY `recovery_codes_user_id_index` (`user_id`),
  KEY `recovery_codes_used_at_index` (`used_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recruitment_requisitions`
--

DROP TABLE IF EXISTS `recruitment_requisitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recruitment_requisitions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `org_unit_id` bigint unsigned NOT NULL,
  `requisition_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `headcount` int unsigned NOT NULL,
  `budget_minor` bigint unsigned DEFAULT NULL,
  `budget_currency` char(3) COLLATE utf8mb4_unicode_ci DEFAULT 'CNY',
  `case_id` bigint unsigned DEFAULT NULL,
  `target_start_date` date DEFAULT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `recruitment_requisitions_requisition_no_unique` (`requisition_no`),
  KEY `recruitment_requisitions_org_unit_id_index` (`org_unit_id`),
  KEY `recruitment_requisitions_case_id_index` (`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `report_definitions`
--

DROP TABLE IF EXISTS `report_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_definitions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `is_system` tinyint(1) NOT NULL DEFAULT '1',
  `code` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_projection` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `as_of_supported` tinyint(1) NOT NULL DEFAULT '1',
  `fields_json` json NOT NULL,
  `filters_json` json NOT NULL,
  `drilldown_route` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `catalog_version` int unsigned NOT NULL DEFAULT '1',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `report_definitions_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `report_runs`
--

DROP TABLE IF EXISTS `report_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_runs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `definition_code` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `as_of` date NOT NULL,
  `filters_json` json DEFAULT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'RUNNING',
  `row_count` bigint unsigned NOT NULL DEFAULT '0',
  `requested_by` bigint unsigned NOT NULL,
  `started_at` timestamp NOT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `failure_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `report_subscriptions`
--

DROP TABLE IF EXISTS `report_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `owner_user_id` bigint unsigned NOT NULL,
  `recipient_user_id` bigint unsigned NOT NULL,
  `definition_code` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `frequency` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filters_json` json DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `last_run_at` timestamp NULL DEFAULT NULL,
  `next_run_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reporting_projection_rows`
--

DROP TABLE IF EXISTS `reporting_projection_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reporting_projection_rows` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `source_projection` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_date` date NOT NULL,
  `metric_code` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ROW',
  `entity_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employment_id` bigint unsigned DEFAULT NULL,
  `org_unit_id` bigint unsigned DEFAULT NULL,
  `label` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secondary_label` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numeric_value` bigint NOT NULL DEFAULT '0',
  `attributes_json` json DEFAULT NULL,
  `source_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `computed_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fb899aa82556629b0254ee1c86a774b9` (`source_projection`,`business_date`,`entity_type`,`entity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `requisition_openings`
--

DROP TABLE IF EXISTS `requisition_openings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `requisition_openings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `requisition_id` bigint unsigned NOT NULL,
  `channel` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'OPEN',
  `published_at` timestamp NULL DEFAULT NULL,
  `closed_at` timestamp NULL DEFAULT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `requisition_openings_requisition_id_channel_unique` (`requisition_id`,`channel`),
  KEY `requisition_openings_requisition_id_index` (`requisition_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `retention_purge_runs`
--

DROP TABLE IF EXISTS `retention_purge_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `retention_purge_runs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `retention_class` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mode` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `candidates` int unsigned NOT NULL DEFAULT '0',
  `held` int unsigned NOT NULL DEFAULT '0',
  `purged` int unsigned NOT NULL DEFAULT '0',
  `report_json` json DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `finished_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_capabilities`
--

DROP TABLE IF EXISTS `role_capabilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_capabilities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `role_code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `capability_code` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `anchor_type` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SELF',
  `anchor_id` bigint unsigned DEFAULT NULL,
  `field_profile` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'P0_PUBLIC',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_capability_anchor_unique` (`role_code`,`capability_code`,`anchor_type`)
) ENGINE=InnoDB AUTO_INCREMENT=373 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_pages`
--

DROP TABLE IF EXISTS `role_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_pages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `role_code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_code` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_pages_role_page_unique` (`role_code`,`page_code`),
  KEY `role_pages_role_code_index` (`role_code`)
) ENGINE=InnoDB AUTO_INCREMENT=218 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `version` int unsigned NOT NULL DEFAULT '1',
  `owner` bigint unsigned DEFAULT NULL,
  `purpose` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`code`),
  KEY `roles_expires_at_index` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `salary_adjustments`
--

DROP TABLE IF EXISTS `salary_adjustments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salary_adjustments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `effective_from` date NOT NULL,
  `currency` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CNY',
  `base_salary_cents` bigint unsigned NOT NULL,
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `case_id` bigint unsigned NOT NULL,
  `compensation_id` bigint unsigned NOT NULL,
  `created_by` bigint unsigned NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `salary_adjustments_case_id_unique` (`case_id`),
  KEY `salary_adjustments_employment_id_index` (`employment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `token_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `csrf_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mfa_challenge_hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mfa_challenge_expires_at` timestamp NULL DEFAULT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `mfa_verified` tinyint(1) NOT NULL DEFAULT '0',
  `mfa_verified_until` timestamp NULL DEFAULT NULL,
  `auth_version` bigint unsigned NOT NULL,
  `idle_expires_at` timestamp NOT NULL,
  `absolute_expires_at` timestamp NOT NULL,
  `revoked_at` timestamp NULL DEFAULT NULL,
  `last_seen_at` timestamp NOT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sessions_token_hash_unique` (`token_hash`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_idle_expires_at_index` (`idle_expires_at`),
  KEY `sessions_absolute_expires_at_index` (`absolute_expires_at`),
  KEY `sessions_revoked_at_index` (`revoked_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shift_assignments`
--

DROP TABLE IF EXISTS `shift_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shift_assignments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `shift_template_id` bigint unsigned NOT NULL,
  `valid_from` date NOT NULL,
  `valid_to` date NOT NULL,
  `source` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MANUAL',
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shift_schedules`
--

DROP TABLE IF EXISTS `shift_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shift_schedules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `business_date` date NOT NULL,
  `shift_template_id` bigint unsigned NOT NULL,
  `created_by` bigint unsigned NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shift_schedules_employment_id_business_date_unique` (`employment_id`,`business_date`),
  KEY `shift_schedules_employment_id_index` (`employment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shift_templates`
--

DROP TABLE IF EXISTS `shift_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shift_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_local_time` time NOT NULL,
  `end_local_time` time NOT NULL,
  `crosses_midnight` tinyint(1) NOT NULL DEFAULT '0',
  `break_minutes` smallint unsigned NOT NULL DEFAULT '0',
  `late_grace_minutes` smallint unsigned NOT NULL DEFAULT '0',
  `early_grace_minutes` smallint unsigned NOT NULL DEFAULT '0',
  `standard_hours_decimal` decimal(8,6) NOT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `valid_from` date NOT NULL,
  `valid_to` date NOT NULL,
  `source_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MANUAL',
  `source_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recorded_at` timestamp(6) NULL DEFAULT NULL,
  `superseded_at` timestamp(6) NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shift_templates_code_version_valid_from_unique` (`code`,`version`,`valid_from`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `statutory_parameters`
--

DROP TABLE IF EXISTS `statutory_parameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `statutory_parameters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `parameter_set` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value_decimal` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value_int` bigint DEFAULT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date NOT NULL DEFAULT '9999-12-31',
  `version` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `approved_by` bigint unsigned NOT NULL,
  `approved_at` datetime(6) NOT NULL,
  `evidence_ref` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_demo` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp(6) NULL DEFAULT NULL,
  `updated_at` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_2a2cd77ba6bbeedf7e1b00da22ad546e` (`parameter_set`,`code`,`version`,`effective_from`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stg_assignments`
--

DROP TABLE IF EXISTS `stg_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stg_assignments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `run_id` bigint unsigned NOT NULL,
  `source_row_number` int unsigned NOT NULL,
  `row_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `raw_json` json NOT NULL,
  `normalized_json` json DEFAULT NULL,
  `validation_status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `target_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stg_assignments_run_row_unique` (`run_id`,`source_row_number`),
  CONSTRAINT `stg_assignments_run_id_foreign` FOREIGN KEY (`run_id`) REFERENCES `migration_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stg_leave_openings`
--

DROP TABLE IF EXISTS `stg_leave_openings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stg_leave_openings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `run_id` bigint unsigned NOT NULL,
  `source_row_number` int unsigned NOT NULL,
  `row_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `raw_json` json NOT NULL,
  `normalized_json` json DEFAULT NULL,
  `validation_status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `target_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stg_leave_openings_run_row_unique` (`run_id`,`source_row_number`),
  CONSTRAINT `stg_leave_openings_run_id_foreign` FOREIGN KEY (`run_id`) REFERENCES `migration_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stg_organizations`
--

DROP TABLE IF EXISTS `stg_organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stg_organizations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `run_id` bigint unsigned NOT NULL,
  `source_row_number` int unsigned NOT NULL,
  `row_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `raw_json` json NOT NULL,
  `normalized_json` json DEFAULT NULL,
  `validation_status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `target_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stg_organizations_run_row_unique` (`run_id`,`source_row_number`),
  CONSTRAINT `stg_organizations_run_id_foreign` FOREIGN KEY (`run_id`) REFERENCES `migration_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stg_payroll_ytd`
--

DROP TABLE IF EXISTS `stg_payroll_ytd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stg_payroll_ytd` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `run_id` bigint unsigned NOT NULL,
  `source_row_number` int unsigned NOT NULL,
  `row_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `raw_json` json NOT NULL,
  `normalized_json` json DEFAULT NULL,
  `validation_status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `target_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stg_payroll_ytd_run_row_unique` (`run_id`,`source_row_number`),
  CONSTRAINT `stg_payroll_ytd_run_id_foreign` FOREIGN KEY (`run_id`) REFERENCES `migration_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stg_people`
--

DROP TABLE IF EXISTS `stg_people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stg_people` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `run_id` bigint unsigned NOT NULL,
  `source_row_number` int unsigned NOT NULL,
  `row_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `raw_json` json NOT NULL,
  `normalized_json` json DEFAULT NULL,
  `validation_status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `target_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stg_people_run_row_unique` (`run_id`,`source_row_number`),
  CONSTRAINT `stg_people_run_id_foreign` FOREIGN KEY (`run_id`) REFERENCES `migration_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stg_terms`
--

DROP TABLE IF EXISTS `stg_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stg_terms` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `run_id` bigint unsigned NOT NULL,
  `source_row_number` int unsigned NOT NULL,
  `row_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `raw_json` json NOT NULL,
  `normalized_json` json DEFAULT NULL,
  `validation_status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `target_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stg_terms_run_row_unique` (`run_id`,`source_row_number`),
  CONSTRAINT `stg_terms_run_id_foreign` FOREIGN KEY (`run_id`) REFERENCES `migration_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_dictionaries`
--

DROP TABLE IF EXISTS `sys_dictionaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_dictionaries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sys_dictionaries_type_code_unique` (`type`,`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_parameters`
--

DROP TABLE IF EXISTS `sys_parameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_parameters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(96) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value_json` json NOT NULL,
  `scope` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TENANT',
  `sensitive` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sys_parameters_key_scope_unique` (`key`,`scope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `talent_pool_tags`
--

DROP TABLE IF EXISTS `talent_pool_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `talent_pool_tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `candidate_id` bigint unsigned NOT NULL,
  `tag` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `retention_until` date DEFAULT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `talent_pool_tags_candidate_id_tag_unique` (`candidate_id`,`tag`),
  KEY `talent_pool_tags_candidate_id_index` (`candidate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tax_brackets`
--

DROP TABLE IF EXISTS `tax_brackets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tax_brackets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `parameter_set_id` bigint unsigned NOT NULL,
  `lower_bound_cents` bigint NOT NULL,
  `upper_bound_cents` bigint DEFAULT NULL,
  `rate_bps` int unsigned NOT NULL,
  `quick_deduction_cents` bigint NOT NULL DEFAULT '0',
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tax_bracket_order_idx` (`parameter_set_id`,`lower_bound_cents`),
  KEY `tax_brackets_parameter_set_id_index` (`parameter_set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `time_payroll_fact_rows`
--

DROP TABLE IF EXISTS `time_payroll_fact_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `time_payroll_fact_rows` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `fact_version_id` bigint unsigned NOT NULL,
  `employment_id` bigint unsigned NOT NULL,
  `business_date` date NOT NULL,
  `range_start` date DEFAULT NULL,
  `range_end` date DEFAULT NULL,
  `scheduled_minutes` int unsigned NOT NULL DEFAULT '0',
  `worked_minutes` int unsigned NOT NULL DEFAULT '0',
  `paid_leave_minutes` int unsigned NOT NULL DEFAULT '0',
  `partial_leave_minutes` int unsigned NOT NULL DEFAULT '0',
  `unpaid_leave_minutes` int unsigned NOT NULL DEFAULT '0',
  `overtime_pay_minutes` int unsigned NOT NULL DEFAULT '0',
  `overtime_timeoff_minutes` int unsigned NOT NULL DEFAULT '0',
  `travel_minutes` int unsigned NOT NULL DEFAULT '0',
  `leave_type_id` bigint unsigned DEFAULT NULL,
  `leave_policy_version_id` bigint unsigned DEFAULT NULL,
  `overtime_category` varchar(24) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `travel_mode` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_type` varchar(48) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_revision` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approval_status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recorded_at` timestamp(6) NOT NULL,
  `created_at` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `time_payroll_fact_row_source_unique` (`fact_version_id`,`employment_id`,`business_date`,`source_type`,`source_id`),
  KEY `time_payroll_fact_employment_day_idx` (`fact_version_id`,`employment_id`,`business_date`),
  KEY `time_payroll_fact_rows_fact_version_id_index` (`fact_version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `time_payroll_fact_versions`
--

DROP TABLE IF EXISTS `time_payroll_fact_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `time_payroll_fact_versions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `period` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int unsigned NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'OPEN',
  `source_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exception_count` int unsigned NOT NULL DEFAULT '0',
  `precheck_json` json DEFAULT NULL,
  `generated_at` timestamp(6) NOT NULL,
  `closed_at` timestamp(6) NULL DEFAULT NULL,
  `closed_by` bigint unsigned DEFAULT NULL,
  `reopened_at` timestamp(6) NULL DEFAULT NULL,
  `reopened_by` bigint unsigned DEFAULT NULL,
  `reopen_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reopened_from_version_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp(6) NULL DEFAULT NULL,
  `updated_at` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `time_payroll_fact_version_unique` (`period`,`version`),
  KEY `time_payroll_fact_period_status_idx` (`period`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `time_period_locks`
--

DROP TABLE IF EXISTS `time_period_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `time_period_locks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `month` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(6) NULL DEFAULT NULL,
  `updated_at` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `time_period_locks_month_unique` (`month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `timeoff_ledger_entries`
--

DROP TABLE IF EXISTS `timeoff_ledger_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `timeoff_ledger_entries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `overtime_settlement_id` bigint unsigned DEFAULT NULL,
  `entry_type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity_minutes` int NOT NULL,
  `effective_on` date NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` bigint unsigned NOT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `timeoff_ledger_entries_overtime_settlement_id_unique` (`overtime_settlement_id`),
  KEY `timeoff_ledger_balance_lookup` (`employment_id`,`effective_on`),
  KEY `timeoff_ledger_entries_employment_id_index` (`employment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `training_checkins`
--

DROP TABLE IF EXISTS `training_checkins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training_checkins` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `session_id` bigint unsigned NOT NULL,
  `employment_id` bigint unsigned NOT NULL,
  `checked_in_at` timestamp NOT NULL,
  `checked_out_at` timestamp NULL DEFAULT NULL,
  `recorded_by` bigint unsigned DEFAULT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `training_checkins_session_id_employment_id_unique` (`session_id`,`employment_id`),
  KEY `training_checkins_session_id_index` (`session_id`),
  KEY `training_checkins_employment_id_index` (`employment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `training_courses`
--

DROP TABLE IF EXISTS `training_courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training_courses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `plan_id` bigint unsigned DEFAULT NULL,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instructor` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery_mode` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ONSITE',
  `duration_minutes` int unsigned NOT NULL DEFAULT '0',
  `cost_cents` bigint unsigned NOT NULL DEFAULT '0',
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CNY',
  `materials` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `training_courses_code_unique` (`code`),
  KEY `training_courses_plan_id_index` (`plan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `training_enrollments`
--

DROP TABLE IF EXISTS `training_enrollments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training_enrollments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `session_id` bigint unsigned NOT NULL,
  `employment_id` bigint unsigned NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ENROLLED',
  `attended` tinyint(1) NOT NULL DEFAULT '0',
  `completion_result` varchar(24) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `score` smallint unsigned DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `training_enrollments_session_id_employment_id_unique` (`session_id`,`employment_id`),
  KEY `training_enrollments_session_id_index` (`session_id`),
  KEY `training_enrollments_employment_id_index` (`employment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `training_exam_attempts`
--

DROP TABLE IF EXISTS `training_exam_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training_exam_attempts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `exam_id` bigint unsigned NOT NULL,
  `session_id` bigint unsigned DEFAULT NULL,
  `enrollment_id` bigint unsigned NOT NULL,
  `employment_id` bigint unsigned NOT NULL,
  `attempt_no` int unsigned NOT NULL,
  `score` smallint unsigned NOT NULL,
  `passed` tinyint(1) NOT NULL,
  `answers_json` json DEFAULT NULL,
  `source_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `submitted_at` datetime(6) NOT NULL,
  `recorded_by` bigint unsigned NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `training_exam_attempt_unique` (`exam_id`,`enrollment_id`,`attempt_no`),
  KEY `training_exam_attempts_exam_id_index` (`exam_id`),
  KEY `training_exam_attempts_session_id_index` (`session_id`),
  KEY `training_exam_attempts_enrollment_id_index` (`enrollment_id`),
  KEY `training_exam_attempts_employment_id_index` (`employment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `training_exams`
--

DROP TABLE IF EXISTS `training_exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training_exams` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint unsigned DEFAULT NULL,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `passing_score` smallint unsigned NOT NULL,
  `max_score` smallint unsigned NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `published_at` datetime(6) DEFAULT NULL,
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `session_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `training_exams_code_version_unique` (`code`,`version`),
  KEY `training_exams_course_id_index` (`course_id`),
  KEY `training_exams_session_id_index` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `training_feedback`
--

DROP TABLE IF EXISTS `training_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training_feedback` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `enrollment_id` bigint unsigned NOT NULL,
  `session_id` bigint unsigned NOT NULL,
  `employment_id` bigint unsigned NOT NULL,
  `rating` smallint unsigned DEFAULT NULL,
  `comments` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `questionnaire_json` json DEFAULT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'RECORDED',
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `training_feedback_enrollment_id_index` (`enrollment_id`),
  KEY `training_feedback_session_id_index` (`session_id`),
  KEY `training_feedback_employment_id_index` (`employment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `training_plans`
--

DROP TABLE IF EXISTS `training_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training_plans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` smallint unsigned NOT NULL,
  `budget_cents` bigint unsigned NOT NULL DEFAULT '0',
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CNY',
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `training_plans_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `training_programs`
--

DROP TABLE IF EXISTS `training_programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training_programs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `default_capacity` smallint unsigned NOT NULL DEFAULT '0',
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `training_programs_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `training_sessions`
--

DROP TABLE IF EXISTS `training_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training_sessions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `program_id` bigint unsigned NOT NULL,
  `starts_on` date NOT NULL,
  `ends_on` date NOT NULL,
  `starts_at` datetime(6) NOT NULL,
  `ends_at` datetime(6) NOT NULL,
  `capacity` smallint unsigned NOT NULL,
  `location` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SCHEDULED',
  `recorded_at` datetime(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `plan_id` bigint unsigned DEFAULT NULL,
  `course_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `training_sessions_program_id_index` (`program_id`),
  KEY `training_sessions_plan_id_index` (`plan_id`),
  KEY `training_sessions_course_id_index` (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `travel_attendance_links`
--

DROP TABLE IF EXISTS `travel_attendance_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel_attendance_links` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `travel_id` bigint unsigned NOT NULL,
  `employment_id` bigint unsigned NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `source_case_id` bigint unsigned NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `retired_at` datetime(6) DEFAULT NULL,
  `retire_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp(6) NULL DEFAULT NULL,
  `updated_at` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `travel_attendance_links_travel_id_unique` (`travel_id`),
  KEY `travel_attendance_range_idx` (`employment_id`,`from_date`,`to_date`),
  KEY `travel_attendance_links_employment_id_index` (`employment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `travel_expenses`
--

DROP TABLE IF EXISTS `travel_expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel_expenses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employment_id` bigint unsigned NOT NULL,
  `travel_id` bigint unsigned NOT NULL,
  `category` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount_cents` bigint unsigned NOT NULL,
  `receipt_file_id` bigint unsigned DEFAULT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CLAIMED',
  `note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `travel_expenses_employment_id_index` (`employment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `travel_policies`
--

DROP TABLE IF EXISTS `travel_policies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel_policies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `city_tier` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hotel_cap_cents` bigint unsigned NOT NULL,
  `transport_cap_cents` bigint unsigned NOT NULL DEFAULT '0',
  `effective_from` date NOT NULL,
  `version` int unsigned NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PUBLISHED',
  `created_by` bigint unsigned NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `travel_policies_city_tier_effective_from_unique` (`city_tier`,`effective_from`),
  UNIQUE KEY `travel_policies_city_tier_version_unique` (`city_tier`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `travel_request_changes`
--

DROP TABLE IF EXISTS `travel_request_changes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel_request_changes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `travel_id` bigint unsigned NOT NULL,
  `employment_id` bigint unsigned NOT NULL,
  `case_id` bigint unsigned DEFAULT NULL,
  `original_json` json NOT NULL,
  `proposed_json` json NOT NULL,
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `recorded_at` datetime(6) NOT NULL,
  `applied_at` datetime(6) DEFAULT NULL,
  `created_at` timestamp(6) NULL DEFAULT NULL,
  `updated_at` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `travel_request_changes_case_id_unique` (`case_id`),
  KEY `travel_change_status_idx` (`travel_id`,`status`),
  KEY `travel_request_changes_travel_id_index` (`travel_id`),
  KEY `travel_request_changes_employment_id_index` (`employment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `role_code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valid_from` timestamp NOT NULL,
  `valid_to` timestamp NOT NULL,
  `granted_by` bigint unsigned DEFAULT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auth_version` bigint unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_roles_user_id_index` (`user_id`),
  KEY `user_roles_role_code_index` (`role_code`),
  KEY `user_roles_valid_from_index` (`valid_from`),
  KEY `user_roles_valid_to_index` (`valid_to`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `auth_version` bigint unsigned NOT NULL DEFAULT '1',
  `person_id` bigint unsigned DEFAULT NULL,
  `mfa_enrolled_at` timestamp NULL DEFAULT NULL,
  `is_privileged` tinyint(1) NOT NULL DEFAULT '0',
  `last_login_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  KEY `users_person_id_index` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `workflow_delegations`
--

DROP TABLE IF EXISTS `workflow_delegations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workflow_delegations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `proxy_user_id` bigint unsigned NOT NULL,
  `principal_user_id` bigint unsigned NOT NULL,
  `valid_from` date NOT NULL,
  `valid_to` date NOT NULL,
  `max_amount_minor` bigint unsigned DEFAULT NULL,
  `scope_json` json DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `revoked_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `workflow_instances`
--

DROP TABLE IF EXISTS `workflow_instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workflow_instances` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `case_id` bigint unsigned NOT NULL,
  `current_node_key` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `started_at` timestamp NOT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `workflow_instances_case_id_unique` (`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `workflow_tasks`
--

DROP TABLE IF EXISTS `workflow_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workflow_tasks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `case_id` bigint unsigned NOT NULL,
  `node_key` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `assignee_user_id` bigint unsigned NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `due_at` timestamp NULL DEFAULT NULL,
  `acted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `workflow_tasks_case_id_node_key_assignee_user_id_unique` (`case_id`,`node_key`,`assignee_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `workflow_template_nodes`
--

DROP TABLE IF EXISTS `workflow_template_nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workflow_template_nodes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `template_id` bigint unsigned NOT NULL,
  `key` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sequence` int unsigned NOT NULL,
  `assignee_rule_json` json DEFAULT NULL,
  `condition_json` json DEFAULT NULL,
  `required_count` int unsigned NOT NULL DEFAULT '1',
  `sla_hours` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `workflow_template_nodes_template_id_key_unique` (`template_id`,`key`),
  KEY `workflow_template_nodes_template_id_sequence_index` (`template_id`,`sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `workflow_templates`
--

DROP TABLE IF EXISTS `workflow_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workflow_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int unsigned NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `definition_json` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `workflow_templates_code_version_unique` (`code`,`version`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'factoryhr_t19'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-28  9:52:37
